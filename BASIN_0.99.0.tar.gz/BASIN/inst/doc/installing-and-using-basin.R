## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
    collapse = TRUE,
    comment = "#>"
)

## ----bioconductor, eval=FALSE--------------------------------------------
#  if (!requireNamespace("BiocManager", quietly = TRUE))
#      install.packages("BiocManager") #installs Bioconductor
#  BiocManager::install("EBImage") #installs EBImage

## ---- eval=FALSE---------------------------------------------------------
#  install.packages("/path/to/BASIN", repos = NULL, type = "source")

## ----setup---------------------------------------------------------------
library(BASIN)

## ----runshinyBASIN, eval = FALSE-----------------------------------------
#  runShinyBASIN()

## ----2-image-------------------------------------------------------------
f = list.files(system.file("2-image", package="BASIN"), full.names=TRUE)

## ----file.copy, eval = FALSE---------------------------------------------
#  file.copy(f, getwd())

## ----list.files----------------------------------------------------------
list.files(getwd())

## ----image-folder--------------------------------------------------------
my_dir <- file.path(getwd(), "Image Folder")
dir.create(my_dir)

## ----eval = FALSE--------------------------------------------------------
#  folder = list.files(system.file("image-folder", package="BASIN"),
#                      full.names = TRUE)
#  file.copy(folder, my_dir)

## ----sessionInfo---------------------------------------------------------
sessionInfo()

