# My Shiny
library(DT)
library(knitr)
library(markdown)
library(plyr)
library(psych)
library(shiny)
library(shinydashboard)
library(shinydashboardPlus)
library(shinyFiles)
library(shinycssloaders)
library(htmlwidgets)
library(plotly)
library(EBImage)
library(ggpubr)
library(ggplot2)

header <- dashboardHeaderPlus(title = tagList(span(class = "logo-lg", "BASIN Image Analysis"),
                                              img(class = "logo-mini", icon("microscope"))))

sidebar <- dashboardSidebar(width = 150, sidebarMenu(
  menuItem(text = "Get Started", icon = icon("compass"), tabName = "getStarted"),
  menuItem(text = "Quick Run", icon = icon("fast-forward"), tabName = "quickRun"),
  menuItem(text = "Upload", icon = icon("cloud-upload"), tabName = "uploadImg", startExpanded = TRUE),
  menuItem(text = "Raw Data", icon = icon("calculator"), tabName = "descStats", startExpanded = TRUE),
  menuItem(text = "Design", icon = icon("check-square"), tabName = "design"),
  menuItem(text = "Results", icon = icon("chart-bar"), tabName = "designResults", startExpanded = TRUE),
  menuItem(text = "Reports", icon = icon("newspaper"), tabName = "reports"),
  menuItem(text = "Publish", icon = icon("cloud-download"), tabName = "publish"),
  tags$footer("Version 1.0.0", align = "left")
)
) # end dashboardSidebar

body <- dashboardBody(
  tabItems(
    # "Get Started" content
    tabItem(tabName = "getStarted",
            fluidPage(tabBox(id = "getStartedTabs", width = 12, title = "Welcome to BASIN!", side = "right", selected = "Home",
                             tabPanel(title = "About", icon = icon("info-circle"),
                                      "Tim Hartman, Research Assistant, University of South Dakota", br(),
                                      "Evgeni Radichev, Research Assistant, University of South Dakota", br(),
                                      "Carrie Minette, Research Assistant, University of South Dakota", br(),
                                      "Maria Hoffman, Research Assistant, University of South Dakota", br(),
                                      "Etienne Gnimpieba PhD, Research Assistant Professor, University of South Dakota", br(),
                                      "Funding provided by the South Dakota Biomedical Research Infrastructure Network (SDBRIN)
                                and BioSystems Networks/Translational Research (BioSNTR)"
                             ),
                             tabPanel(title = "Updates", icon = icon("book"), "Coming soon..."),
                             tabPanel(title = "Contact", icon = icon("address-card"), "Coming soon..."),
                             tabPanel(title = "Tutorials",
                                      icon = icon("file"),
                                      boxPlus(width = "100%", title = "Downloading and Using Example Image Folder (Windows)", status = "warning", collapsible = TRUE, collapsed = TRUE, closable = FALSE,
                                              "The sample folder provided by this app can be found on a public GitHub repository at the following address: ",
                                              tags$a("https://github.com/EvgeniRadichev/BASIN-sample-images", href = "https://github.com/EvgeniRadichev/BASIN-sample-images"), br(),
                                              "1. Click on the 'Download Example Folder' button, which will open a new page in your default browser and start downloading a zipped file", br(),
                                              "2. When prompted, click on 'Open' to open the downloaded file", br(),
                                              "3. Use the 'Extract' option to unzip the compressed folder and save it to a local directory on your computer", br(),
                                              "4. Upload the .csv file contained in the unzipped folder and proceed through the rest of the app"
                                        )
                                      ),
                             tabPanel(title = "FAQs", icon = icon("question"), "Coming soon..."),
                             tabPanel(title = "Data Format", icon = icon("star"), "Coming soon..."),
                             tabPanel(title = "Home", icon = icon("home"),
                                      boxPlus(title = "BASIN Stats (coming soon)", width = 12, status = "success", collapsible = TRUE, collapsed = TRUE, closable = FALSE,
                                              fluidRow(
                                                valueBoxOutput(outputId = "authorsUsed"),
                                                valueBoxOutput(outputId = "imagesAnlzd"),
                                                valueBoxOutput(outputId = "reportsPublsd")
                                              )
                                      ),
                                      "1. Upload either two images or a folder of images with a data file", br(),
                                      "2. View descriptive statistics to validate images", br(),
                                      "3. Design experiment using data file", br(),
                                      "4. Analyze image sets", br(),
                                      "5. Compile report", br(),
                                      "6. Publish results!"
                             )
            )
            )
    ), # End tabItem
    # Quick Run content
    tabItem(tabName = "quickRun",
            fluidPage(tabBox(id = "quickRunTabs", width = 12, title = "Analyze Two Images", height = "1600px", side = "right", selected = "Upload",
                             tabPanel(title = "Publish",
                                      h3("Publish Report"),
                                        tags$a(class = "btn btn-default", target = "_blank", href = "https://www.plos.org/submit", "Submit to PLoS"),
                                        tags$a(class = "btn btn-default", target = "_blank", href = "https://www.openi.nlm.nih.gov", "Submit to Open-i"),
                                        tags$a(class = "btn btn-default", target = "_blank", href = "https://figshare.com", "Submit to FigShare")

                             ),
                             tabPanel(title = "Report",
                                      radioButtons(inputId = 'quickRptFormat', label = 'Document format', c('HTML', 'PDF', 'Word'),
                                                   inline = TRUE),
                                      downloadButton(outputId = "downloadQuickRpt", label = "Generate Report"),
                                      box(width = 12, title = "Report Preview", "Coming Soon...")
                             ),
                             ## Raw Numbers tab panel
                             tabPanel(title = "Result Plots",
                                      withSpinner(plotlyOutput("Barplot3", height = "500px")),
                                      withSpinner(plotlyOutput("Barplot4", height = "500px")),
                                      withSpinner(plotlyOutput("Boxplot3", height = "500px"))
                             ),
                             tabPanel(title = "T-tests",
                                      h5("Image 1 & 2 RGB combined pixels t-test:"),
                                      verbatimTextOutput(outputId = "allTtest"),
                                      h5("Image 1 & 2 red pixels t-test:"),
                                      verbatimTextOutput(outputId = "redTtest"),
                                      h5("Image 1 & 2 green pixels t-test:"),
                                      verbatimTextOutput(outputId = "greenTtest"),
                                      h5("Image 1 & 2 blue pixels t-test:"),
                                      verbatimTextOutput(outputId = "blueTtest")
                             ),
                             ## Raw Graphs tab content
                             tabPanel(title = "Raw Data",
                                      boxPlus(width = 12, title = "Image 1 Statistics", status = "warning", collapsible = TRUE, collapsed = TRUE, closable = FALSE,
                                              h5("Red frame summary:"),
                                              DTOutput(outputId = "R1sum"),
                                              h5("Green frame summary:"),
                                              DTOutput(outputId = "G1sum"),
                                              h5("Blue frame summary:"),
                                              DTOutput(outputId = "B1sum")
                                      ),
                                      boxPlus(width = 12, title = "Image 2 Statistics", status = "warning", collapsible = TRUE, collapsed = TRUE, closable = FALSE,
                                              h5("Red frame summary:"),
                                              DTOutput(outputId = "R2sum"),
                                              h5("Green frame summary:"),
                                              DTOutput(outputId = "G2sum"),
                                              h5("Blue frame summary:"),
                                              DTOutput(outputId = "B2sum")
                                      ),
                                      boxPlus(width = 6, title = "Image 1 graphics:", status = "warning", collapsible = TRUE, collapsed = TRUE, closable = FALSE,
                                              withSpinner(plotOutput(outputId = "hist1", width = "100%", height = "200px")), hr(),
                                              withSpinner(plotlyOutput("img1Barplot", height = "200px")), hr(),
                                              withSpinner(plotlyOutput("img1Boxplot", height = "200px"))
                                      ),
                                      boxPlus(width = 6, title = "Image 2 graphics:", status = "warning", collapsible = TRUE, collapsed = TRUE, closable = FALSE,
                                              withSpinner(plotOutput(outputId = "hist2", width = "100%", height = "200px")), hr(),
                                              withSpinner(plotlyOutput("img2Barplot", height = "200px")), hr(),
                                              withSpinner(plotlyOutput("img2Boxplot", height = "200px"))
                                      )
                             ),
                             ## "Upload" tab content
                             tabPanel(title = "Upload",

                                      actionButton(inputId = "examples", label = "Try Our Example Images"),
                                      "Or Upload Your Own Below",
                                      hr(),

                                      boxPlus(width = 6, status = "warning", collapsible = TRUE, closable = FALSE, title = "Upload Image 1",
                                              fileInput(inputId = "uploadImg1",
                                                        label = "Accepted formats: .png .tif .jpg",
                                                        accept = c(".png", ".tif", ".jpg")),
                                              plotOutput(outputId = "raster1", width = "100%", height = "150px"),
                                              hr(),
                                              plotOutput(outputId = "raster1rgb", width = "100%", height = "150px"),
                                              textInput(inputId = "condition1",
                                                        label = "Name of first image:",
                                                        value = "Condition 1")
                                      ),

                                      boxPlus(width = 6, status = "warning", collapsible = TRUE, closable = FALSE, title = "Upload Image 2",
                                              fileInput(inputId = "uploadImg2",
                                                        label = "Accepted formats: .png .tif .jpg",
                                                        accept = c(".png", ".tif", ".jpg")),
                                              plotOutput(outputId = "raster2", width = "100%", height = "150px"),
                                              hr(),
                                              plotOutput(outputId = "raster2rgb", width = "100%", height = "150px"),
                                              textInput(inputId = "condition2",
                                                        label = "Name of second image:",
                                                        value = "Condition 2")
                                      ),

                                      checkboxGroupInput(inputId = "twoImgAnalyses", label = "Choose BASIN analyses to run:",
                                                         choices = c("RGB pixel intensities"), selected = c("RGB pixel intensities")
                                      ),
                                      actionButton(inputId = "getImageData", label = "Get Image Data"),
                                      actionButton(inputId = "analyzeSingle", label = "Analyze Two Images"),
                                      hr(),
                                      boxPlus(width = 12, title = "Action Log", status = "danger", collapsible = TRUE, collapsed = FALSE, closable = FALSE,
                                              "Coming soon..."
                                              #textOutput(outputId = "acknowledge1"),
                                              #textOutput(outputId = "acknowledge2"),
                                              #textOutput(outputId = "acknowledge3"),
                                              #textOutput(outputId = "storedValues")
                                      )
                             ) ## end Two Images tabPanel
            ) # End tabBox for Quick Run
            ) # End fluidPage
    ), # End tabItem for Quick Run

    # "Upload" content
    tabItem(tabName = "uploadImg",
            fluidPage(
              tags$a(class = "btn btn-default", target = "_blank", href = "https://github.com/EvgeniRadichev/BASIN-sample-images/raw/master/image-folder.zip", "Download Example Folder"),
              "See 'Tutorials' under the 'Get Started' page for details, or upload your data below",
              hr(),
              box(width = 12, title = "Upload a data file in .csv format",
                  fileInput(inputId = "uploadData", label = "Upload file (.csv)", accept = c(".csv"))
              ),
              conditionalPanel(condition = "output.csv_import_ready",
                               box(width = 12, title = "Now upload the contents of your image folder. Image files (.png .tif .jpg) are shown below",
                                   shinyDirButton(id = "directory", label = "Browse Folder", title = "Please select a folder"),
                                   verbatimTextOutput(outputId = "directorypath")
                               )
              ),
              sidebarLayout(
                sidebarPanel(width = 3,
                             uiOutput("folderImgs1"),
                             actionButton(inputId = "validateTable", label = "Validate"),
                             h3(textOutput(outputId = "validateFldrAndTbl"))
                ),
                mainPanel(width = 9,
                          DTOutput(outputId = "imageTable")
                ) # end mainPanel
              ) # end sidebarLayout
              #tableOutput(outputId = "validateResults")
            ) # end fluidPage
    ), # end tabItem
    tabItem(tabName = "descStats",
            fluidPage(
              sidebarLayout(
                sidebarPanel(width = 3,
                             uiOutput("folderImgs2")
                ),
                mainPanel(width = 9,
                          tabBox(id = "rawTabs", width = 12, height = "1600px",
                                 tabPanel(title = "Plots",
                                          box(width = 12, title = "RGB frames separated:",
                                              withSpinner(plotOutput(outputId = "rasterFldrImgrgb",
                                                         width = "100%",
                                                         height = "200px"))
                                          ),
                                          box(width = 12, title = "RGB Intensity Histogram",
                                              withSpinner(plotOutput(outputId = "hist3", width = "100%", height = "200px"))
                                          ),
                                          box(width = 12, title = "RGB Intensity Barplot",
                                              withSpinner(plotlyOutput("fldrImgBarplot", height = "500px"))
                                          ),
                                          box(width = 12, title = "RGB Intensity Boxplot",
                                              withSpinner(plotlyOutput("fldrImgBoxplot", height = "500px"))
                                          )
                                 ),
                                 tabPanel(title = "Numbers",
                                          h3("Warning: Does not update with radio button input"),
                                          h4("Whole image stats:"),
                                          tableOutput(outputId = "fldrImg.stats.All"),
                                          h4("Red frame stats:"),
                                          tableOutput(outputId = "fldrImg.stats.Red"),
                                          h4("Green frame stats:"),
                                          tableOutput(outputId = "fldrImg.stats.Green"),
                                          h4("Blue frame stats:"),
                                          tableOutput(outputId = "fldrImg.stats.Blue")
                                 )
                          ) # End tabBox
                ) # End mainPanel
              ) # End sidebarLayout
            ) # End fluidPage
    ), # end tabItem
    # Design menu content
    tabItem(tabName = "design",
            fluidPage(
              box(width = 4, title = "Choose group to analyze",
                  radioButtons(inputId = "chooseGroup", label = NULL, choices = c(1))
              ),
              box(width = 3, title = "Choose BASIN analyses to run: (not functional)",
                  checkboxGroupInput(inputId = "grpImgAnalyses", label = "",
                                     choices = c("RGB pixel intensities"), selected = c("RGB pixel intensities")),
                  actionButton(inputId = "anlzGrpButton", label = "Analyze Group")
              ),
              box(width = 5, title = "Enter analysis details (not functional)",
                  textInput(inputId = "analysisName", label = "Name:", value = "My Analysis"),
                  textInput(inputId = "analysisGoal", label = "Goal:", value = "My Goal"),
                  textInput(inputId = "analysisDescrip", label = "Description:", value = "My Description")
              ),
              DTOutput(outputId = "imageTable2")
            )
    ),
    # Results >> Result Plots menu content
    tabItem(tabName = "designResults",
            fluidPage(tabBox(id = "anlysResultsTabBox", title = "Analysis Results", width = 12, height = "3000px",
                             tabPanel(title = "Plots",
                                      withSpinner(plotlyOutput(outputId = "Barplot5", height = "500px")),
                                      withSpinner(plotlyOutput(outputId = "Barplot6", height = "500px")),
                                      withSpinner(plotlyOutput(outputId = "Barplot7", height = "500px")),
                                      withSpinner(plotlyOutput(outputId = "Boxplot4", height = "500px")),
                                      withSpinner(plotlyOutput(outputId = "Boxplot5", height = "500px")),
                                      withSpinner(plotlyOutput(outputId = "Boxplot6", height = "500px"))
                             ),
                             tabPanel(title = "Combined Statistics",
                                      h4("RGB combined stats:"),
                                      DTOutput(outputId = "chsnImgs.combinedDF.All"),
                                      h4("Red frame stats:"),
                                      DTOutput(outputId = "chsnImgs.combinedDF.Red"),
                                      h4("Green frame stats:"),
                                      DTOutput(outputId = "chsnImgs.combinedDF.Green"),
                                      h4("Blue frame stats:"),
                                      DTOutput(outputId = "chsnImgs.combinedDF.Blue")
                             )
            ) # End tabBox
            ) # End fluidPage
    ), # End tabItem

    # "Report" tab content
    tabItem(tabName = "reports",
            fluidPage(
              radioButtons('format', 'Document format', c('HTML', 'PDF', 'Word'), inline = TRUE),
              downloadButton(outputId = "downloadReport", label = "Generate Report"),
              box(width = 12, title = "Report Preview", "Coming Soon...")
            )
    ),

    # "Publish" tab content
    tabItem(tabName = "publish",
            fluidPage(
              h3("Publish Report"),
              tags$a(class = "btn btn-default", target = "_blank", href = "https://www.plos.org/submit", "Submit to PLoS"),
              tags$a(class = "btn btn-default", target = "_blank", href = "https://www.openi.nlm.nih.gov", "Submit to Open-i"),
              tags$a(class = "btn btn-default", target = "_blank", href = "https://figshare.com", "Submit to FigShare")
            )
    )
  ), # end tabItems

  # Copyright footer
  tags$style(type = 'text/css',
             "footer{position: absolute; bottom:0%; left: 33%; padding:5px;}"),
  tags$footer("Copyright © 2019 The University of South Dakota. All rights reserved.", align = "right")

) # end dashboardBody

# Put them together into a dashboardPage
dashboardPagePlus(header, sidebar, body, skin = "blue")
