# # My Shiny
# library(DT)
# library(markdown)
# library(plyr)
# library(psych)
# library(shiny)
# library(shinydashboard)
# library(shinydashboardPlus)
# library(shinycssloaders)
# library(shinyFiles)
# library(htmlwidgets)
# library(EBImage)
# library(ggpubr)
# library(ggplot2)
# library(plotly)

shinyServer(function(input, output, session) {
  print(Sys.time())
  # Create storage and retrieval for reactive values
  values <- reactiveValues()

  output$R1sum <- renderDT(datatable(values$R1sum, options = list(dom = 't', scrollX = TRUE)))
  output$G1sum <- renderDT(datatable(values$G1sum, options = list(dom = 't', scrollX = TRUE)))
  output$B1sum <- renderDT(datatable(values$B1sum, options = list(dom = 't', scrollX = TRUE)))
  output$R2sum <- renderDT(datatable(values$R2sum, options = list(dom = 't', scrollX = TRUE)))
  output$G2sum <- renderDT(datatable(values$G2sum, options = list(dom = 't', scrollX = TRUE)))
  output$B2sum <- renderDT(datatable(values$B2sum, options = list(dom = 't', scrollX = TRUE)))
  output$allTtest <- renderPrint(values$allTtest)
  output$redTtest <- renderPrint(values$redTtest)
  output$greenTtest <- renderPrint(values$greenTtest)
  output$blueTtest <- renderPrint(values$blueTtest)

  # "BASIN Stats" value boxes
  output$authorsUsed <- renderValueBox({valueBox("Authors", value = "##", icon = icon("pen"), color = "red")})
  output$imagesAnlzd <- renderValueBox({valueBox("Images Analyzed", value = "##", icon = icon("images"), color = "green")})
  output$reportsPublsd <- renderValueBox({valueBox("Reports Published", value = "##", icon = icon("newspaper"), color = "blue")})

  # Code for downloading example images
  #shinyFileSave(input,id = "examples", roots = c("wd" = ".", "home"))
  output$examples <- downloadHandler(filename = "img1.jpg",
                                     content = function(file) {
                                       download.file(y,'y.jpg', mode = 'wb')
                                     })

  # Code for EBImage to read and display Quick Run >> Single Image 1
  #img1path <- NA
  #img2path <- NA
  img1 <- reactive({
    validate(need(input$uploadImg1$datapath != "" || input$examples, "Please upload a condition 1 image"))
    if(input$examples){
      img1path <<- "https://raw.githubusercontent.com/EvgeniRadichev/BASIN-sample-images/master/img1.jpg"} else {img1path <<- input$uploadImg1$datapath}
    readImage(img1path)
  })
  #output$widget1 <- renderDisplay({display(img1())})
  output$raster1 <- renderPlot({plot(img1(), all=TRUE)})
  observeEvent({!is.null(input$uploadImg1) | input$examples}, {
    values$img1Frm1 <- getFrame(img1(), 1)
    values$img1Frm2 <- getFrame(img1(), 2)
    values$img1Frm3 <- getFrame(img1(), 3)
    output$raster1rgb <- renderPlot({
      plot(abind(channel(values$img1Frm1, "asred"),
                 channel(values$img1Frm2, "asgreen"),
                 channel(values$img1Frm3, "asblue"),
                 along = 1))})
    output$acknowledge1 <- renderText(paste(Sys.time(), "Condition 1 image histogram ready to view."))
  })

  # Code for EBImage to read and display Quick Run >> Single Image 2
  img2 <- reactive({
    validate(need(input$uploadImg2$datapath != "" || input$examples, "Please upload a condition 2 image"))
    if(input$examples){
      img2path <<- "https://raw.githubusercontent.com/EvgeniRadichev/BASIN-sample-images/master/img2.jpg"} else {img2path <<- input$uploadImg2$datapath}
    readImage(img2path)
  })
  #output$widget2 <- renderDisplay({display(img2())})
  output$raster2 <- renderPlot({plot(img2(), all=TRUE)})
  observeEvent({!is.null(input$uploadImg2) | input$examples}, {
    values$img2Frm1 <- getFrame(img2(), 1)
    values$img2Frm2 <- getFrame(img2(), 2)
    values$img2Frm3 <- getFrame(img2(), 3)
    output$raster2rgb <- renderPlot({
      plot(abind(channel(values$img2Frm1, "asred"),
                 channel(values$img2Frm2, "asgreen"),
                 channel(values$img2Frm3, "asblue"),
                 along = 1))})
    output$acknowledge2 <- renderText({
      paste(Sys.time(), "Condition 2 image histogram ready to view.")
    })
  })

  # Code for EBImage to display each Quick Run >> Single Image's frames and graphs
  observeEvent(input$getImageData, {
    output$hist1 <- renderPlot({
      validate(need(input$uploadImg1$datapath != "" || input$examples, "Please upload a condition 1 image"))
      #img1path <- input$uploadImg1$datapath
      hist(x = readImage(img1path), main = paste("Histogram 1.", input$condition1, "RGB Pixel Intensities"))
    })
    output$hist2 <- renderPlot({
      validate(need(input$uploadImg2$datapath != "" || input$examples, "Please upload a condition 2 image"))
      #img2path <- input$uploadImg2$datapath
      hist(x = readImage(img2path), main = paste("Histogram 2.", input$condition2, "RGB Pixel Intensities"))
    })
    ### Convert image frames to matrices
    values$img1Frm1mat <- imageData(values$img1Frm1)
    values$img1Frm2mat <- imageData(values$img1Frm2)
    values$img1Frm3mat <- imageData(values$img1Frm3)
    values$img2Frm1mat <- imageData(values$img2Frm1)
    values$img2Frm2mat <- imageData(values$img2Frm2)
    values$img2Frm3mat <- imageData(values$img2Frm3)
    ### Convert frame matrices to vectors
    values$Rvec1 <- as.vector(values$img1Frm1mat)
    values$Gvec1 <- as.vector(values$img1Frm2mat)
    values$Bvec1 <- as.vector(values$img1Frm3mat)
    values$Rvec2 <- as.vector(values$img2Frm1mat)
    values$Gvec2 <- as.vector(values$img2Frm2mat)
    values$Bvec2 <- as.vector(values$img2Frm3mat)
    ### Frame vector stats
    values$R1sum <- describe(values$Rvec1, check = FALSE, quant = c(.25, .75), IQR = TRUE)
    values$G1sum <- describe(values$Gvec1, check = FALSE, quant = c(.25, .75), IQR = TRUE)
    values$B1sum <- describe(values$Bvec1, check = FALSE, quant = c(.25, .75), IQR = TRUE)
    values$R2sum <- describe(values$Rvec2, check = FALSE, quant = c(.25, .75), IQR = TRUE)
    values$G2sum <- describe(values$Gvec2, check = FALSE, quant = c(.25, .75), IQR = TRUE)
    values$B2sum <- describe(values$Bvec2, check = FALSE, quant = c(.25, .75), IQR = TRUE)
    ### Frame vector means
    values$RmeanImg1 <- mean(values$Rvec1)
    values$GmeanImg1 <- mean(values$Gvec1)
    values$BmeanImg1 <- mean(values$Bvec1)
    values$RmeanImg2 <- mean(values$Rvec2)
    values$GmeanImg2 <- mean(values$Gvec2)
    values$BmeanImg2 <- mean(values$Bvec2)
    ### Frame vector standard errors
    values$Rse1 <- sd(values$Rvec1) / sqrt(length(values$Rvec1))
    values$Gse1 <- sd(values$Gvec1) / sqrt(length(values$Gvec1))
    values$Bse1 <- sd(values$Bvec1) / sqrt(length(values$Bvec1))
    values$Rse2 <- sd(values$Rvec2) / sqrt(length(values$Rvec2))
    values$Gse2 <- sd(values$Gvec2) / sqrt(length(values$Gvec2))
    values$Bse2 <- sd(values$Bvec2) / sqrt(length(values$Bvec2))
    ### Plot variables
    img1SEs <- as.numeric(as.character(c(values$Rse1, values$Gse1, values$Bse1)))
    img2SEs <- as.numeric(as.character(c(values$Rse2, values$Gse2, values$Bse2)))
    img1means <- c(values$RmeanImg1, values$GmeanImg1, values$BmeanImg1)
    img2means <- c(values$RmeanImg2, values$GmeanImg2, values$BmeanImg2)
    Color.Dye <- c("Red", "Green", "Blue")
    values$data1 <- data.frame(image = input$condition1, Color.Dye = Color.Dye, frameMean = img1means, frameSE = img1SEs)
    values$data2 <- data.frame(image = input$condition2, Color.Dye = Color.Dye, frameMean = img2means, frameSE = img2SEs)
    values$data1$Color.Dye <- factor(values$data1$Color.Dye, levels = c("Red", "Green", "Blue"))
    values$data2$Color.Dye <- factor(values$data2$Color.Dye, levels = c("Red", "Green", "Blue"))
    values$data3 <- rbind(values$data1, values$data2)
    ### Frame vectors converted to data frames
    img1RDF <- data.frame(image = "img1.jpg", Color.Dye = "Red", intensity = values$Rvec1)
    img1GDF <- data.frame(image = "img1.jpg", Color.Dye = "Green", intensity = values$Gvec1)
    img1BDF <- data.frame(image = "img1.jpg", Color.Dye = "Blue", intensity = values$Bvec1)
    img1DF <- rbind(img1RDF, img1GDF, img1BDF)
    img2RDF <- data.frame(image = "img2.jpg", Color.Dye = "Red", intensity = values$Rvec2)
    img2GDF <- data.frame(image = "img2.jpg", Color.Dye = "Green", intensity = values$Gvec2)
    img2BDF <- data.frame(image = "img2.jpg", Color.Dye = "Blue", intensity = values$Bvec2)
    img2DF <- rbind(img2RDF, img2GDF, img2BDF)
    values$data4 <- rbind(img1DF, img2DF)
    ## Image 1 RGB Barplot
    output$img1Barplot <- renderPlotly({
      validate(need(input$uploadImg1$datapath != "" || input$examples, "Please upload a condition 1 image"))
      values$img1Barplot <- ggplot(data = values$data1, mapping = aes(x = Color.Dye, y = frameMean, fill = Color.Dye)) +
        geom_bar(stat = "identity", position = position_dodge()) +
        geom_errorbar(mapping = aes(x = Color.Dye, ymin = frameMean - frameSE, ymax = frameMean + frameSE),
                      width = 0.4, position = position_dodge(0.9), colour = "orange", alpha = 0.9, size = 1.3) +
        labs(title = paste("Barplot 1.", input$condition1, "Mean Intensities"), x = "Image Frames", y = "Mean Color Intensity") +
        theme(legend.position = "none")
      ggplotly(values$img1Barplot) %>%
        layout(height = input$plotHeight, autosize = TRUE)
    })
    ## Image 2 RGB Barplot
    output$img2Barplot <- renderPlotly({
      validate(need(input$uploadImg2$datapath != "" || input$examples, "Please upload a condition 2 image"))
      values$img2Barplot <- ggplot(data = values$data2, mapping = aes(x = Color.Dye, y = img2means, fill = Color.Dye)) +
        geom_bar(stat = "identity", position = position_dodge()) +
        geom_errorbar(mapping = aes(x = Color.Dye, ymin = img2means - img2SEs, ymax = img2means + img2SEs),
                      width = 0.4, position = position_dodge(0.9), colour = "orange", alpha = 0.9, size = 1.3) +
        labs(title = paste("Barplot 2.", input$condition2, "Mean Intensities"), x = "Image Frames", y = "Mean Color Intensity") +
        theme(legend.position = "none")
      ggplotly(values$img2Barplot) %>%
        layout(height = input$plotHeight, autosize = TRUE)
    })
    ## Image 1 RGB Boxplot
    output$img1Boxplot <- renderPlotly({
      validate(need(input$uploadImg1$datapath != "" || input$examples, "Please upload a condition 1 image"))
      values$img1Boxplot <- ggplot(data = img1DF, aes(x = Color.Dye, y = intensity, fill = Color.Dye)) +
        geom_boxplot() +
        scale_y_continuous() +
        labs(title = paste("Boxplot 1.", input$condition1, "Mean Intensities"), x = "Image Frames", y = "Color Intensity") +
        theme(legend.position = "none")
      ggplotly(values$img1Boxplot) %>%
        layout(height = input$plotHeight, autosize = TRUE)
    })
    ## Image 2 RGB Boxplot
    output$img2Boxplot <- renderPlotly({
      validate(need(input$uploadImg2$datapath != "" || input$examples, "Please upload a condition 2 image"))
      values$img2Boxplot <- ggplot(data = img2DF, aes(x = Color.Dye, y = intensity, fill = Color.Dye)) +
        geom_boxplot() +
        scale_y_continuous() +
        labs(title = paste("Boxplot 2.", input$condition2, "Mean Intensities"), x = "Image Frames", y = "Color Intensity") +
        theme(legend.position = "none")
      ggplotly(values$img2Boxplot) %>%
        layout(height = input$plotHeight, autosize = TRUE)
    })
  })
  observeEvent(input$analyzeSingle, {
    ## Image 1 & 2 Barplot
    output$Barplot3 <- renderPlotly({
      values$Barplot3 <- ggplot(data = values$data3, mapping = aes(x = image, y = frameMean, fill = Color.Dye)) +
        geom_bar(stat = "identity", position = position_dodge()) +
        geom_errorbar(aes(x = image, ymin = frameMean - frameSE, ymax = frameMean + frameSE), width = 0.4,
                      position = position_dodge(0.9), colour = "orange", alpha = 0.9, size = 1.3) +
        labs(title = paste("Barplot 3.", input$condition1, "vs.", input$condition2), x = "Image Frames", y = "Mean Color Intensity") +
        theme(legend.position = "none")
      ggplotly(values$Barplot3) %>%
        layout(height = input$plotHeight, autosize = TRUE)
    })
    ## Image 1 & 2 Barplot
    output$Barplot4 <- renderPlotly({
      values$Barplot4 <- ggbarplot(data = values$data4, x = "image", y = "intensity",
                                   fill = "Color.Dye", stat = "identity", position = position_dodge(), color = "Orange", palette = c('#FF6666', '#66CC66', '#3399FF'),
                                   add = c("mean_se"), error.plot = "errorbar",
                                   facet.by = "Color.Dye", panel.labs = list(Color.Dye = c("Red", "Green", "Blue")), short.panel.labs = FALSE ,
                                   title = paste("Barplot 4.", input$condition1, "vs.", input$condition2), xlab = "Image Frames", ylab = "Mean Color Intensity") +
        stat_compare_means(aes(label = paste0("p = ", ..p.format..))) +
        theme(legend.position = "none", axis.text.x = element_text(angle = 90, hjust = 1))
      ggplotly(values$Barplot4) %>%
        layout(height = input$plotHeight, autosize = TRUE)
    })
    ## Image 1 & 2 Boxplot
    output$Boxplot3 <- renderPlotly({
      values$Boxplot3 <- ggboxplot(data = values$data4, x = "image", y = "intensity",
                                   fill = "Color.Dye", color = "Orange", palette = c('#FF6666', '#66CC66', '#3399FF'),
                                   facet.by = "Color.Dye", panel.labs = list(Color.Dye = c("Blue", "Green", "Red")), short.panel.labs = FALSE ,
                                   title = paste("Boxplot 3.", input$condition1, "vs.", input$condition2), xlab = "Image Frames", ylab = "Color Intensity") +
        stat_compare_means(aes(label = paste0("p = ", ..p.format..))) +
        theme(legend.position = "none", axis.text.x = element_text(angle = 90, hjust = 1))
      ggplotly(values$Boxplot3) %>%
        layout(height = input$plotHeight, autosize = TRUE)
    })
    img1Vec <- c(values$Rvec1, values$Gvec1, values$Bvec1)
    img2Vec <- c(values$Rvec2, values$Gvec2, values$Bvec2)
    values$allTtest <- t.test(img1Vec, img2Vec)
    values$redTtest <- t.test(values$Rvec1, values$Rvec2)
    values$greenTtest <- t.test(values$Gvec1, values$Gvec2)
    values$blueTtest <- t.test(values$Bvec1, values$Bvec2)
  })

  # Markdown document for quick report
  options(tinytex.verbose = TRUE)
  output$downloadQuickRpt <- downloadHandler(
    filename = function() {
      paste('my-quickreport', sep = '.', switch(input$quickRptFormat, HTML = 'html', PDF = 'pdf', Word = 'docx'))
    },
    content = function(file) {
      src <- file.path(path.package('BASIN'), 'templates/quickreport.Rmd')
      #src <- file.path(getwd(), 'inst/templates/quickreport.Rmd')
      # temporarily switch to the temp dir, in case you do not have write
      # permission to the current working directory
      owd <- setwd(tempdir())
      on.exit(expr = setwd(owd))
      file.copy(src, 'quickreport.Rmd', overwrite = TRUE)
      library(rmarkdown)
      out <- render('quickreport.Rmd', switch(
        input$quickRptFormat,
        HTML = html_document(), PDF = pdf_document(), Word = word_document()
      ))
      file.rename(out, file)
    }
  )

  # Code to display Upload >> Data File as a table
  options(DT.options = list(pageLength = 20))
  output$imageTable <- renderDT(server = FALSE, expr = {
    validate(need(input$uploadData$datapath != "",
                  "Please upload a file with comma-separated values format"))
    values$imgTable <- read.csv(file = input$uploadData$datapath, header = TRUE, stringsAsFactors = TRUE)
    values$imgTable
  }, editable = FALSE, options = list(dom = 't', scrollX = TRUE))
  output$csv_import_ready <- reactive({
    return(!is.null(input$uploadData))
  })
  outputOptions(output, "csv_import_ready", suspendWhenHidden = FALSE)

  # Code for uploading Folder directory
  output$directorypath <- renderPrint(parseDirPath(volumes, input$directory))
  dirPath <- renderPrint(paste(parseDirPath(volumes, input$directory)))
  observeEvent(eventExpr = input$directory, {
    values$fldr.files <- list.files(paste(parseDirPath(volumes, input$directory)), pattern = c("jpg", "tif", "png"))
    values$fldr.files <- values$fldr.files[order(match(values$fldr.files, as.character(values$imgTable2$filename)))]
    output$folderImgs1 <- renderUI({
      radioButtons(inputId = "folderImgs1", label = "Images from directory (radio buttons not functional)", choices = values$fldr.files)
    })
    output$folderImgs2 <- renderUI({
      radioButtons(inputId = "folderImgs2", label = "Images from directory", choices = values$fldr.files)
    })
  })

  # Upload "Validate" button
  observeEvent(input$validateTable, {
    output$validateFldrAndTbl <- renderPrint({
      identical(as.character(values$imgTable2$filename), values$fldr.files)
    })
  })

  # Code for getting, displaying Folder contents
  volumes <- c(Home = fs::path_home(), "R Installation" = R.home(), getVolumes()())
  shinyDirChoose(input = input, id = "directory", roots = volumes, session = session, restrictions = system.file(package = "base"))

  # Raw Data graphics for selected image
  fldrImg <- reactive({
    values$fldrImgpath <- paste(parseDirPath(volumes, input$directory), "/", input$folderImgs2, sep = "")
    readImage(values$fldrImgpath)
  })
  output$rasterFldrImgrgb <- renderPlot({
    plot(abind(channel(getFrame(fldrImg(), 1), "asred"),
               channel(getFrame(fldrImg(), 2), "asgreen"),
               channel(getFrame(fldrImg(), 3), "asblue"),
               along = 1))
  })
  # Single folder image histogram
  output$hist3 <- renderPlot({
    hist(x = fldrImg(), main = paste("Histogram 3.", input$folderImgs2, "RGB Pixel Intensities"))
  })

  ## Single folder image RGB Barplot
  output$fldrImgBarplot <- renderPlotly({
    ### Isolate image frames
    values$fldrImgFrm1 <- getFrame(fldrImg(), 1)
    values$fldrImgFrm2 <- getFrame(fldrImg(), 2)
    values$fldrImgFrm3 <- getFrame(fldrImg(), 3)
    ### Convert frame matrices to vectors
    values$fldrImg.asVec.Red <- as.vector(imageData(values$fldrImgFrm1))
    values$fldrImg.asVec.Green <- as.vector(imageData(values$fldrImgFrm2))
    values$fldrImg.asVec.Blue <- as.vector(imageData(values$fldrImgFrm3))
    values$fldrImg.asVec.All <- c(values$fldrImg.asVec.Red, values$fldrImg.asVec.Green, values$fldrImg.asVec.Blue)
    ### All stats using "describe" from Psych package
    values$fldrImg.stats.All <- describe(values$fldrImg.asVec.All, check = FALSE, quant = c(.25, .75), IQR = TRUE)
    values$fldrImg.stats.Red <- describe(values$fldrImg.asVec.Red, check = FALSE, quant = c(.25, .75), IQR = TRUE)
    values$fldrImg.stats.Green <- describe(values$fldrImg.asVec.Green, check = FALSE, quant = c(.25, .75), IQR = TRUE)
    values$fldrImg.stats.Blue <- describe(values$fldrImg.asVec.Blue, check = FALSE, quant = c(.25, .75), IQR = TRUE)
    ### Frame vector means
    fldrImg.mean.Red <- mean(values$fldrImg.asVec.Red)
    fldrImg.mean.Green <- mean(values$fldrImg.asVec.Green)
    fldrImg.mean.Blue <- mean(values$fldrImg.asVec.Blue)
    ### Frame vector standard errors
    fldrImg.se.Red <- sd(values$fldrImg.asVec.Red) / sqrt(length(values$fldrImg.asVec.Red))
    fldrImg.se.Green <- sd(values$fldrImg.asVec.Green) / sqrt(length(values$fldrImg.asVec.Green))
    fldrImg.se.Blue <- sd(values$fldrImg.asVec.Blue) / sqrt(length(values$fldrImg.asVec.Blue))
    ### Plot variables
    img1SEs <- as.numeric(as.character(c(fldrImg.se.Red, fldrImg.se.Green, fldrImg.se.Blue)))
    img1means <- c(fldrImg.mean.Red, fldrImg.mean.Green, fldrImg.mean.Blue)
    image.names <- c(input$folderImgs2, input$folderImgs2, input$folderImgs2)
    Color.Dye <- c("Red", "Green", "Blue")
    data <- data.frame(Color.Dye, image.names, img1means, img1SEs)
    data$Color.Dye <- factor(data$Color.Dye, levels = c("Red", "Green", "Blue"))
    ### ggplot barplot build
    img1Barplot <- ggplot(data = data, mapping = aes(x = Color.Dye, y = img1means, fill = Color.Dye)) +
      geom_bar(stat = "identity", position = position_dodge()) +
      geom_errorbar(mapping = aes(x = Color.Dye, ymin = img1means - img1SEs, ymax = img1means + img1SEs),
                    width = 0.4, position = position_dodge(0.9), colour = "orange", alpha = 0.9, size = 1.3) +
      labs(title = input$folderImgs2, x = "Image Frames", y = "Mean Color Intensity") +
      theme(legend.position = "none")
    ggplotly(img1Barplot) %>%
      layout(height = input$plotHeight, autosize = TRUE)
  })

  ## Single folder image RGB Boxplot
  output$fldrImgBoxplot <- renderPlotly(
    {
    ### Convert frame matrices to vectors
    img1RDF <- data.frame(group = "Red", value = values$fldrImg.asVec.Red)
    img1GDF <- data.frame(group = "Green", value = values$fldrImg.asVec.Green)
    img1BDF <- data.frame(group = "Blue", value = values$fldrImg.asVec.Blue)
    img1DF <- rbind(img1RDF, img1GDF, img1BDF)
    img1Boxplot1 <- ggplot(data = img1DF, aes(x = group, y = value, fill = group)) +
      geom_boxplot() +
      scale_y_continuous() +
      labs(title = input$folderImgs2, x = "Image Frames", y = "Color Intensity") +
      theme(legend.position = "none")
    ggplotly(img1Boxplot1) %>%
      layout(height = input$plotHeight, autosize = TRUE)
  })

  # Raw Data, Numbers tab content
  output$fldrImg.stats.All <- renderTable({validate(need(input$validateTable,"Please upload images"))
                                          values$fldrImg.stats.All})
  output$fldrImg.stats.Red <- renderTable({validate(need(input$validateTable,"Please upload images"))
                                          values$fldrImg.stats.Red})
  output$fldrImg.stats.Green <- renderTable({validate(need(input$validateTable,"Please upload images"))
                                          values$fldrImg.stats.Green})
  output$fldrImg.stats.Blue <- renderTable({validate(need(input$validateTable,"Please upload images"))
                                          values$fldrImg.stats.Blue})

  # Show CSV data table in "Design"
  imgTable2 <- reactive({
  })
  imgTable2Groups <- reactive(levels(imgTable2()$img.grp))
  observeEvent(input$uploadData, {
    values$imgTable2 <- read.csv(file = input$uploadData$datapath, header = TRUE, stringsAsFactors = TRUE)
    output$imageTable2 <- renderDT(server = FALSE, expr = {
      datatable(data = values$imgTable2, rownames = FALSE, selection = "none", editable = FALSE) %>%
        formatStyle(columns = 'img.grp', target = 'row',
                    backgroundColor = styleEqual(c(1, 2, 3), c('#fff991', '#ee91ff', '#91f4ff'))
        )
    })
    updateRadioButtons(session, inputId = "chooseGroup",
                       choices = levels(factor(values$imgTable2$img.grp,
                                               levels = unique(values$imgTable2$img.grp))))
  })

  # Printing things to console for testing
  observe({
    #print(values$chsnImgs.Filepaths)
  })

  # [Group image] Results body content
  observeEvent(input$anlzGrpButton, {
    values$chsnImgs <- filter(.data = values$imgTable2, img.grp == as.numeric(input$chooseGroup))
    values$chsnImgs <- droplevels(values$chsnImgs, exclude = if(anyNA(levels(values$chsnImgs))) NULL else NA)
    chsnImgs.Filename <- as.character(values$chsnImgs$filename)
    chsnImgs.Filepaths <- lapply(chsnImgs.Filename, function(x) paste(parseDirPath(volumes, input$directory), "/", x, sep = ""))
    values$chsnImgs.asList.All <- lapply(chsnImgs.Filepaths, readImage)
    chsnImgs.asList.All <- lapply(values$chsnImgs.asList.All, imageData)
    names(chsnImgs.asList.All) <- chsnImgs.Filename
    # Red, green, blue lists of matrices
    chsnImgs.asList.Red <- lapply(chsnImgs.asList.All, function(x) getFrame(x, 1))
    chsnImgs.asList.Green <- lapply(chsnImgs.asList.All, function(x) getFrame(x, 2))
    chsnImgs.asList.Blue <- lapply(chsnImgs.asList.All, function(x) getFrame(x, 3))
    chsnImgs.asList.Red <- lapply(chsnImgs.asList.Red, imageData)
    chsnImgs.asList.Green <- lapply(chsnImgs.asList.Green, imageData)
    chsnImgs.asList.Blue <- lapply(chsnImgs.asList.Blue, imageData)
    # All, red, green, blue lists of vectors
    chsnImgs.asVec.All <- lapply(chsnImgs.asList.All, as.vector)
    chsnImgs.asVec.Red <- lapply(chsnImgs.asList.Red, as.vector)
    chsnImgs.asVec.Green <- lapply(chsnImgs.asList.Green, as.vector)
    chsnImgs.asVec.Blue <- lapply(chsnImgs.asList.Blue, as.vector)
    # All, red, green, blue lists of stats and 5-summaries
    chsnImgs.stats.All <- lapply(chsnImgs.asVec.All, function(x) describe(x, check = FALSE, quant = c(.25, .75), IQR = TRUE))
    chsnImgs.stats.Red <- lapply(chsnImgs.asVec.Red, function(x) describe(x, check = FALSE, quant = c(.25, .75), IQR = TRUE))
    chsnImgs.stats.Green <- lapply(chsnImgs.asVec.Green, function(x) describe(x, check = FALSE, quant = c(.25, .75), IQR = TRUE))
    chsnImgs.stats.Blue <- lapply(chsnImgs.asVec.Blue, function(x) describe(x, check = FALSE, quant = c(.25, .75), IQR = TRUE))
    # All, red, green, blue data frames of stats
    chsnImgs.statsDF.All <- do.call(rbind.data.frame, chsnImgs.stats.All)
    chsnImgs.statsDF.Red <- do.call(rbind.data.frame, chsnImgs.stats.Red)
    chsnImgs.statsDF.Green <- do.call(rbind.data.frame, chsnImgs.stats.Green)
    chsnImgs.statsDF.Blue <- do.call(rbind.data.frame, chsnImgs.stats.Blue)
    rownames(chsnImgs.statsDF.All) <- NULL
    rownames(chsnImgs.statsDF.Red) <- NULL
    rownames(chsnImgs.statsDF.Green) <- NULL
    rownames(chsnImgs.statsDF.Blue) <- NULL
    values$chsnImgs.combinedDF.All <- cbind(values$chsnImgs, chsnImgs.statsDF.All)
    values$chsnImgs.combinedDF.Red <- cbind(values$chsnImgs, chsnImgs.statsDF.Red)
    values$chsnImgs.combinedDF.Green <- cbind(values$chsnImgs, chsnImgs.statsDF.Green)
    values$chsnImgs.combinedDF.Blue <- cbind(values$chsnImgs, chsnImgs.statsDF.Blue)
    chsnImgs.asDF.Red <- setNames(ldply(chsnImgs.asVec.Red, function(i) data.frame(i)) , c("filename", "intensity"))
    chsnImgs.asDF.Green <- setNames(ldply(chsnImgs.asVec.Green, function(i) data.frame(i)) , c("filename", "intensity"))
    chsnImgs.asDF.Blue <- setNames(ldply(chsnImgs.asVec.Blue, function(i) data.frame(i)) , c("filename", "intensity"))
    chsnImgs.asDF.Red$filename <- factor(chsnImgs.asDF.Red$filename, levels = chsnImgs.Filename)
    chsnImgs.asDF.Green$filename <- factor(chsnImgs.asDF.Green$filename, levels = chsnImgs.Filename)
    chsnImgs.asDF.Blue$filename <- factor(chsnImgs.asDF.Blue$filename, levels = chsnImgs.Filename)

    # Barplot of group images' red frames
    output$Barplot5 <- renderPlotly({
      values$Barplot5 <- ggplot(data = values$chsnImgs.combinedDF.Red, mapping = aes(x = filename, y = mean)) +
        geom_bar(stat = "identity", position = position_dodge(), fill = rgb(200/255, 0, 0)) +
        geom_errorbar(aes(x = filename, ymin = mean - se, ymax = mean + se), width = 0.4,
                      position = position_dodge(0.9), colour = "orange", alpha = 0.9, size = 1.3) +
        labs(title = paste("Barplot 5. Red Intensities of Group", input$chooseGroup, "Images"), x = "Image Filename", y = "Mean Color Intensity") +
        theme(legend.position = "none", axis.text.x = element_text(angle = 45, hjust = 1))
      ggplotly(values$Barplot5) %>%
        layout(height = input$plotHeight, autosize = TRUE)
    })

    # Barplot of group images' green frames
    output$Barplot6 <- renderPlotly({
      values$Barplot6 <- ggplot(data = values$chsnImgs.combinedDF.Green, mapping = aes(x = filename, y = mean)) +
        geom_bar(stat = "identity", position = position_dodge(), fill = rgb(0, 200/255, 0)) +
        geom_errorbar(aes(x = filename, ymin = mean - se, ymax = mean + se), width = 0.4,
                      position = position_dodge(0.9), colour = "orange", alpha = 0.9, size = 1.3) +
        labs(title = paste("Barplot 6. Green Intensities of Group", input$chooseGroup, "Images"), x = "Image Filename", y = "Mean Color Intensity") +
        theme(legend.position = "none", axis.text.x = element_text(angle = 45, hjust = 1))
      ggplotly(values$Barplot6) %>%
        layout(height = input$plotHeight, autosize = TRUE)
    })

    # Barplot of group images' blue frames
    output$Barplot7 <- renderPlotly({
      values$Barplot7 <- ggplot(data = values$chsnImgs.combinedDF.Blue, mapping = aes(x = filename, y = mean)) +
        geom_bar(stat = "identity", position = position_dodge(), fill = rgb(0, 0, 200/255)) +
        geom_errorbar(aes(x = filename, ymin = mean - se, ymax = mean + se), width = 0.4,
                      position = position_dodge(0.9), colour = "orange", alpha = 0.9, size = 1.3) +
        labs(title = paste("Barplot 6. Green Intensities of Group", input$chooseGroup, "Images"), x = "Image Filename", y = "Mean Color Intensity") +
        theme(legend.position = "none", axis.text.x = element_text(angle = 45, hjust = 1))
      ggplotly(values$Barplot7) %>%
        layout(height = input$plotHeight, autosize = TRUE)
    })

    # Boxplot of group images' red frames
    output$Boxplot4 <- renderPlotly({
      values$Boxplot4 <- ggboxplot(data = chsnImgs.asDF.Red, x = "filename", y = "intensity",
                                   fill = rgb(200/255, 0, 0), color = "Orange",
                                   title = paste("Boxplot 4. Red Intensities of Group", input$chooseGroup, "Images"), xlab = "Image Filename", ylab = "Color Intensity") +
        stat_compare_means(method = "anova", label.x = 1.5, label.y = 1.2) +
        theme(legend.position = "none", axis.text.x = element_text(angle = 45, hjust = 1))
      ggplotly(values$Boxplot4) %>%
        layout(height = input$plotHeight, autosize = TRUE)
    })

    # Boxplot of group images' green frames
    output$Boxplot5 <- renderPlotly({
      values$Boxplot5 <- ggboxplot(data = chsnImgs.asDF.Green, x = "filename", y = "intensity",
                                   fill = rgb(0, 200/255, 0), color = "Orange",
                                   title = paste("Boxplot 5. Green Intensities of Group", input$chooseGroup, "Images"), xlab = "Image Filename", ylab = "Color Intensity") +
        stat_compare_means(method = "anova", label.x = 1.5, label.y = 1.2) +
        theme(legend.position = "none", axis.text.x = element_text(angle = 45, hjust = 1))
      ggplotly(values$Boxplot5) %>%
        layout(height = input$plotHeight, autosize = TRUE)
    })

    # Boxplot of group images' blue frames
    output$Boxplot6 <- renderPlotly({
      values$Boxplot6 <- ggboxplot(data = chsnImgs.asDF.Blue, x = "filename", y = "intensity",
                                   fill = rgb(0, 0, 200/255), color = "Orange",
                                   title = paste("Boxplot 6. Blue Intensities of Group", input$chooseGroup, "Images"), xlab = "Image Filename", ylab = "Color Intensity") +
        stat_compare_means(method = "anova", label.x = 1.5, label.y = 1.2) +
        theme(legend.position = "none", axis.text.x = element_text(angle = 45, hjust = 1))
      ggplotly(values$Boxplot6) %>%
        layout(height = input$plotHeight, autosize = TRUE)
    })

    # Group T-test results
    output$chsnImgs.combinedDF.All <- renderDT({values$chsnImgs.combinedDF.All}, options = list(dom = 't', scrollX = TRUE))
    output$chsnImgs.combinedDF.Red <- renderDT({values$chsnImgs.combinedDF.Red}, options = list(dom = 't', scrollX = TRUE))
    output$chsnImgs.combinedDF.Green <- renderDT({values$chsnImgs.combinedDF.Green}, options = list(dom = 't', scrollX = TRUE))
    output$chsnImgs.combinedDF.Blue <- renderDT({values$chsnImgs.combinedDF.Blue}, options = list(dom = 't', scrollX = TRUE))
  }) # End of observeEvent(input$anlzGrpButton,...

  # Markdown document
  options(tinytex.verbose = TRUE)
  output$downloadReport <- downloadHandler(
    filename = function() {
      paste('my-report', sep = '.', switch(
        input$format, HTML = 'html', PDF = 'pdf', Word = 'docx'
      ))
    },
    content = function(file) {
      src <- file.path(path.package('BASIN'), 'templates/report.Rmd')
      #src <- file.path(getwd(), 'inst/templates/report.Rmd')
      # temporarily switch to the temp dir, in case you do not have write
      # permission to the current working directory
      owd <- setwd(tempdir())
      on.exit(expr = setwd(owd))
      file.copy(src, 'report.Rmd', overwrite = TRUE)
      library(rmarkdown)
      out <- render('report.Rmd', switch(
        input$format,
        HTML = html_document(), PDF = pdf_document(), Word = word_document()
      ))
      file.rename(out, file)
    }
  )

  # Code for EBImage to read and display Multi-Image Figure
  fig <- reactive({
    figpath <- input$uploadFig$datapath
    readImage(figpath)})
  output$widgetFig <- renderDisplay({
    display(fig())})
  output$rasterFig <- renderPlot({
    plot(fig(), all=TRUE)})
}) # End shinyServer

