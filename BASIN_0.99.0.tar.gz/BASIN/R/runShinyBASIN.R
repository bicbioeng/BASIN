#' ShinyBASIN
#'
#' This function runs the Shiny app for the BASIN workflow.
#'
#' @export
#' @import knitr
#' @import markdown
#' @import shiny
#' @import shinydashboard
#' @import shinycssloaders
#' @import shinyFiles
#' @import htmlwidgets
#' @import EBImage
#' @import ggplot2
#' @import shinydashboardPlus
#' @importFrom DT DTOutput "%>%" JS datatable formatStyle renderDT styleEqual
#' @importFrom plyr dlply
#' @importFrom psych describe
#' @importFrom plotly ggplotly layout plotlyOutput renderPlotly style
#' @importFrom ggpubr ggboxplot ggbarplot stat_compare_means mean_se_
#'
#' @return shiny app UI
#'
#' @examples
#' {  #Note the conditional is only there for package checks
#'  if(interactive()){
#'      runShinyBASIN()
#'  }
#' }
runShinyBASIN <- function(){
    appDir <- system.file("shiny-examples",
                        package = "BASIN")
    if (appDir == "") {
        stop("Could not find example directory. Try re-installing `BASIN`.",
            call. = FALSE)
    }
    shiny::runApp(appDir, display.mode = "normal")
}
